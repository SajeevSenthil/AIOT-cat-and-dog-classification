# Cat and Dog Image Classifer 

A new Flutter-TFLite Project

## Getting Started

This project is a starting point for a Flutter application.
This project uses Flutter to make an app which can be run on android, IOS and Windows for classifying images of cats and dogs alone
It makes use of a machine learnign model (TFLite model) to predict the images




https://github.com/Anirudh2465/Cat-Dog-Classifier/assets/110315983/fd1e7b41-9a39-4e77-bdf3-26525aa37bec

