package com.example.cat_dog

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
